// const element = document.getElementById("nome");
// element.addEventListener("onkeypress", () => {
//   document.getElementById("exibe_nome").innerHTML = element.value + " ";

// });